package productionCode;

import domusObjects.*;
import java.util.*;
import java.io.FileWriter;
import java.io.IOException;

public class productionAppareil{

    static String parseCType(Type t){
        String s = t.nom;
        switch(s){
            case "eclariage" :
                return "CEclairage";

            case "volet" :
                return "CVoletFenetre";

            case "fenetre" :
                return "CVoletFenetre";

            case "chauffage" :
                return "CChauffage";

            case "alarme" :
            return "CAlarme";

            default :
                return "CAutreAppareil";
        }
    }

    static String parseNomTypeEnum(Type t){
        String s = t.nom;
        switch(s){
            case "cafe" :
                return "AUTRE_APPAREIL_"+t.nom.toUpperCase();

            case "tv" :
                return "AUTRE_APPAREIL_"+t.nom.toUpperCase();

            case "hifi" :
                return "AUTRE_APPAREIL_"+t.nom.toUpperCase();

            case "video_proj" :
                return "AUTRE_APPAREIL_"+t.nom.toUpperCase();

            case "lave_linge" :
                return "AUTRE_APPAREIL_LL";

            case "lave_vaisselle" :
                return "AUTRE_APPAREIL_LV";

            case "seche_linge" :
                return "AUTRE_APPAREIL_SL";

            case "portail" :
                return "AUTRE_APPAREIL_"+t.nom.toUpperCase();

            default :
                return t.nom.toUpperCase();
        }
    }

    public static void ecriture( HashMap<String, Appareil> tableAppareils, FileWriter writer){

        try{

        writer.write("\t\t//  Appareils\n");

        Collection<Appareil> appareils = tableAppareils.values();
        Appareil app;

        for (Iterator<Appareil> itr = appareils.iterator(); itr.hasNext();){
            app = itr.next();

            writer.write("\t\t"+parseCType(app.type) + " "+app.nom+" = new "+parseCType(app.type)+"(\""+app.nom+"\",TypeAppareil."+parseNomTypeEnum(app.type)+");\n");
            writer.write("\t\tma_liste_appareils.add("+app.nom+");\n");
        }

        writer.write("\n");
    } catch(IOException e) {
        System.out.println("Erreur productionAppareil\n");
    }
    }

}