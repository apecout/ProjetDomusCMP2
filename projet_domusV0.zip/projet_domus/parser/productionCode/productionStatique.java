package productionCode;

import java.io.FileWriter;
import java.io.IOException;

public class productionStatique{

    public static void ecritureDebut(FileWriter writer){

        System.out.println("productionStatique : debut");
        try{
            writer.write("// CMaisonUser.java\n");
            writer.write("\n");
            writer.write("public class CMaisonUser extends CMaison {\n");
            writer.write("\tpublic CMaisonUser() {\n");
            writer.write("\t\tsuper();\n");
            writer.write("\n");
        } catch ( IOException e){
            System.out.println("Erreur écriture productionStatique debut");
        }
        System.out.println("productionStatique : fin");
    }

    public static void ecritureFin(FileWriter writer){

        try{
            writer.write("\t\tmonHabitat = new HabitatSpecific(ma_liste_appareils,\n");
            writer.write("\t\tma_liste_ens_appareils, ma_liste_scenarios,\n");
            writer.write("\t\tma_liste_interfaces, ma_liste_programmations);\n");
            writer.write("\t}\n");
            writer.write("}\n");
        } catch (IOException e){
            System.out.println("Erreur écriture productionStatique fin");
        }

    }
}
