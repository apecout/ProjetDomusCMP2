package productionCode;

import domusObjects.*;
import java.util.*;
import java.io.FileWriter;
import java.io.IOException;

public class productionInterface{

    public static void ecriture( HashMap<String, DomusInterface> tableInterfaces, FileWriter writer ){
        System.out.println("productionInterfaces : debut");
        try{
            writer.write("\t\t//  Interfaces\n");
    
            Collection<DomusInterface> interfaces = tableInterfaces.values();
            DomusInterface inter;
    
            for (Iterator<DomusInterface> itr = interfaces.iterator(); itr.hasNext();){
                inter = itr.next();
    
                writer.write("\t\tCInterface "+ inter.nom +"= new CInterface(\""+inter.nom+"\",TypeInterface."+inter.type.toUpperCase()+");\n");
                writer.write("\t\tma_liste_interfaces.add("+inter.nom+");\n");
            }
            writer.write("");

        } catch(IOException e) {
            System.out.println("Erreur productionInterfaces");
        }

        System.out.println("productionInterfaces : debut");
    }

}