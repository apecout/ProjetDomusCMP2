package productionCode;

import domusObjects.*;
import java.util.*;
import java.io.FileWriter;
import java.io.IOException;


public class productionCommande{

    public static void ecritureAssocations( HashMap<String, DomusInterface> tableInterfaces, FileWriter writer ){
        System.out.println("productionCommande associations : debut");
        try{
            writer.write("\t\t//  Commande associations\n");
    
            Collection<DomusInterface> interfaces = tableInterfaces.values();
            DomusInterface inter;
    
            for (Iterator<DomusInterface> itr = interfaces.iterator(); itr.hasNext();){
                inter = itr.next();
    
                for(String scenario : inter.scenariosAssocies)
                writer.write("\t\t"+ inter.nom+".addScenarioAssocie(\""+scenario+"\");\n");
            }
            writer.write("\n");
        } catch (IOException e) {
            System.out.println("Erreur productionCommande associations");
        }
        System.out.println("productionCommande associations : fin");
    }

    public static void ecritureProgrammations( HashMap<String, DomusScenario> tableScenarios, FileWriter writer ){
        System.out.println("productionCommande programmation : debut");
        try {
            writer.write("\t\t//  Commande programmation\n");
    
            Collection<DomusScenario> scenarios = tableScenarios.values();
            DomusScenario scenar;
            int idProgrammation = 1;
            int idDate = 1;
    
            for (Iterator<DomusScenario> itr = scenarios.iterator(); itr.hasNext();){
                scenar = itr.next();
    
                writer.write("\t\tCProgrammation p"+ idProgrammation +" = new CProgrammation(\""+scenar.nom+"\");\n");
    
                for(CDate d : scenar.listeDate){
                    writer.write("\t\tCDate p"+idProgrammation+"d"+idDate+" = new CDate("+d.annee+", "+d.mois+", "+d.jour+", "+d.heure+", "+d.minute+");\n");
                    writer.write("\t\tp"+ idProgrammation +".addDate( p"+idProgrammation+"d"+idDate+");\n");
                    idDate++;
                }
                writer.write("\t\tma_liste_programmations.add(p"+idProgrammation+"); \n");
                writer.write("\n");
                idProgrammation++;
                idDate = 1;
            }
        } catch (IOException e) {
            System.out.println("Erreur productionCommande programmation");
        }

        System.out.println("productionCommande programmation : fin");
    }

}

