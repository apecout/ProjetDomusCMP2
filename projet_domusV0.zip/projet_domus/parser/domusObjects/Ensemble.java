package domusObjects;

import java.util.ArrayList;

public class Ensemble{
	String nom;
	ArrayList<Appareil> ensemble;
	
	public Ensemble(String nom, ArrayList<Appareil> ensemble){
		this.nom=nom;
		this.ensemble=ensemble;
	}
}
