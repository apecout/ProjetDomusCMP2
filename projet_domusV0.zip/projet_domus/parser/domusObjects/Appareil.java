package domusObjects;

public class Appareil {
    public String nom;
    public Type type;
    
    public Appareil(String nom, Type type){
        this.nom=nom;
        this.type=type;

    }
}