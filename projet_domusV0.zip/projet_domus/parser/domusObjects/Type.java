package domusObjects;

import java.util.ArrayList;

public class Type {
    public String nom;
    public ArrayList<String> action;
    
    public Type(String nom){
        this.nom=nom;
        
        ArrayList<String> list = new ArrayList<String>();
        if(nom.equals("eclairage")){
            list.add("allumer");
            list.add("allumer_partiel");
            list.add("eteindre");
            action = list;
        } else if(nom.equals("alarme")){
            list.add("allumer");
            list.add("allumer_partiel");
            list.add("eteindre");
            action = list;
        } else if(nom.equals("chauffage")){
            list.add("allumer");
            list.add("allumer_éco");
            list.add("eteindre");
            action = list;

        } else if(nom.equals("fenetre")){
            list.add("ouvrir");
            list.add("ouvrir_partiel");
            list.add("fermer");
            list.add("fermer_partiel");
            action = list;

        } else if(nom.equals("volet")){
            list.add("ouvrir");
            list.add("ouvrir_partiel");
            list.add("fermer");
            list.add("fermer_partiel");
            action = list;

        } else if(nom.equals("")){
            list.add("allumer");
            list.add("fermer");
            action = list;
        } else ;
    }
}


//-------------
