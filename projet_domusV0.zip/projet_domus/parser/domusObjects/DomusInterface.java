package domusObjects;

import java.util.*;

public class DomusInterface {
    public String nom;
    public String type;
    public ArrayList<String> scenariosAssocies;

    public DomusInterface(String nom, String type){
        this.nom = nom; 
        this.type = type;
        this.scenariosAssocies = new ArrayList<String>();
    }
}
