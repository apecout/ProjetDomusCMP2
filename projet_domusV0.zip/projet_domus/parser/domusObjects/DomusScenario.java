package domusObjects;

import java.util.ArrayList;

public class DomusScenario {

    private static int IndexGeneral = 0;
    
    public String nom;
    public ArrayList<String> contenu;
    public ArrayList<CDate> listeDate;
    private int numero = 0;
    
    public DomusScenario(String nom){
        this.nom = nom; 
        this.contenu = new ArrayList<String>();
        this.listeDate = new ArrayList<CDate>();
        numero = IndexGeneral ++;
    }

    Integer getNumero(){
        return this.numero;
    }
}
