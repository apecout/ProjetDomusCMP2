#!/bin/bash
# script pour lancer le compilateur de langage domus
#le repertoire parser et ce script doivent etre au meme endroit
# prend en 1er argument le chemin vers le fichier d'entrée
# prend en 2eme argument le chemin vers le repertoire de sortie 
	#si il n'est pas renseigné ou incorrect :
	#alors les fichier se trouveront dans ./parser

IN=$1
OUTDIR=$2

echo "   "
echo "	compilation de "$IN
echo "	vers "$OUTDIR

cd parser/

#compilation du langage
java parser < ../$IN
wait $!
echo "   "
echo "   compilation terminee"

#deplacement des fichers generes dans le repertoire de sortie
cp CMaisonUser.java ../$OUTDIR/
cp HabitatSpecific.java ../$OUTDIR/

echo "   "
echo "   fichiers generes dans "$OUTDIR
echo "   "
